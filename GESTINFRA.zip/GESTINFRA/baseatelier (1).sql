-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  Dim 30 oct. 2022 à 13:47
-- Version du serveur :  10.1.25-MariaDB
-- Version de PHP :  7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `baseatelier`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `cni` varchar(30) NOT NULL,
  `ville` varchar(30) NOT NULL,
  `tel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenom`, `cni`, `ville`, `tel`) VALUES
(5, 'syntiche', 'maeva', 'iuc20e0055237', 'yaoundé', 695447937),
(9, 'Meli', 'Gloria', 'cnei456', 'mbouda', 691650889),
(11, 'maeva', 'djoko', '123cv', 'buea', 699826931);

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `numero` int(11) NOT NULL,
  `nclient` varchar(30) NOT NULL,
  `produitcom` varchar(30) NOT NULL,
  `punitaire` double NOT NULL,
  `quant` int(11) NOT NULL,
  `ptotal` double NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`numero`, `nclient`, `produitcom`, `punitaire`, `quant`, `ptotal`, `date`) VALUES
(1, 'mme djoko', 'chaises', 5000, 20, 150000, '2021-12-08'),
(2, 'syntiche', 'table', 1200, 50, 6000, '2021-11-30'),
(7, 'gloria', 'tableau en bois', 1000, 70, 3000, '2021-12-02'),
(8, 'Meli', 'mae mae', 200000, 23, 460000000, '2021-12-21'),
(9, 'gloria', 'tableau en bois', 1000, 10, 3000, '2021-12-02'),
(10, 'Meli', 'chaises', 120000, 1, 240000, '2022-06-02'),
(11, 'syntiche', 'chaises en fer', 1000, 20, 0, '2022-06-04');

-- --------------------------------------------------------

--
-- Structure de la table `fournisseur`
--

CREATE TABLE `fournisseur` (
  `id` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `adresse` varchar(30) NOT NULL,
  `ville` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `categorieM` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `fournisseur`
--

INSERT INTO `fournisseur` (`id`, `nom`, `adresse`, `ville`, `email`, `categorieM`) VALUES
(28, 'maeva syntiche', '670747949', 'buea', 'maevadjoko@gmail.com', 'clou'),
(30, 'mae', '695447937', 'maroua', 'maevadjoko9@gmail.com', 'bois et fer'),
(31, 'mae mae', 'ndogpassi', 'douala', 'ljuhg', 'pas lourd');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `id` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `categoriep` varchar(30) NOT NULL,
  `prixunitaire` double NOT NULL,
  `quantite` varchar(30) NOT NULL,
  `remise` double NOT NULL,
  `prixvente` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id`, `nom`, `categoriep`, `prixunitaire`, `quantite`, `remise`, `prixvente`) VALUES
(8, 'chaises en fer', 'pas lourd', 1000, '1', 0, 1000),
(10, 'mae mae', 'cnkel', 45, '1', 0, 456),
(12, 'vitres', 'fumées', 120000, '1000', 0.5, 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `identifiant` int(11) NOT NULL,
  `login` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`identifiant`, `login`, `password`) VALUES
(1, 'maeva Djoko', 'vroumette'),
(2, 'syntiche', 'cameroun');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`numero`);

--
-- Index pour la table `fournisseur`
--
ALTER TABLE `fournisseur`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`identifiant`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `numero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `fournisseur`
--
ALTER TABLE `fournisseur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `identifiant` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
